
function num2e(num){
	if(num>1000||num<0.0001){
		var p = Math.floor(Math.log(num)/Math.LN10);
		var n = num * Math.pow(10, -p);
		n = n.toFixed(4)
		return n + 'e' + p;
	}
	else{
		n = num.toFixed(4)
		return n
	}  
}
function num3e(num){
	
	n = num.toFixed(4)
	return n
 
}

<!--长度换算函数-->
function length(){
	let data = document.getElementById('in_len').value
	let val_in = parseFloat(data)
	var eSelect = document.getElementById('choose_len')
	var index=eSelect.selectedIndex
	let unit = eSelect.options[index].value
	console.log(unit)
	if(unit=='m'){
		out_m = val_in
		out_ft = 3.2808*val_in
		out_um = val_in*1e6
	}
	else if(unit=='ft'){
		out_m = val_in/3.2808
		out_ft = 3.2808*out_m
		out_um = out_m*1e6
	}
	else{
		out_m = val_in/1e6
		out_ft = 3.2808*out_m
		out_um = out_m*1e6
	}
	
	out_m = num2e(out_m)
	out_ft = num2e(out_ft)
	out_um = num2e(out_um)
	result_len.innerText = out_m+"m"+"           "+out_ft+"ft"+"           "+out_um+"μm"
}

<!--粘度换算函数-->
function viscosity(){
	let data = document.getElementById('in_vis').value
	let val_in = parseFloat(data)
	var eSelect = document.getElementById('choose_vis')
	var index=eSelect.selectedIndex
	let unit = eSelect.options[index].value
	console.log(unit)
	if(unit=='cp'){
		out_cp = val_in
		out_pas = 1e-3*val_in
		out_mpas = val_in
	}
	else if(unit=='mpas'){
		out_cp = val_in*1e3
		out_pas = out_cp/1e3
		out_mpas = out_cp
	}
	else{
		out_cp = val_in
		out_pas = 1e-3*out_cp
		out_mpas = out_cp
	}
	
	out_cp = num2e(out_cp)
	out_pas = num2e(out_pas)
	out_mpas = num2e(out_mpas)
	result_vis.innerText = out_cp+"cP"+"           "+out_pas+"Pa·s"+"           "+out_mpas+"mPa·s"
}

<!--压力换算函数-->
function pressure(){
	let data = document.getElementById('in_pre').value
	let val_in = parseFloat(data)
	var eSelect = document.getElementById('choose_pre')
	var index=eSelect.selectedIndex
	let unit = eSelect.options[index].value
	console.log(unit)
	if(unit=='MPa'){
		out_MPa = val_in
		out_KPa = 1e3*val_in
		out_Pa = 1e6*val_in
		out_mPa = 1e9*val_in
		out_psi = 145*val_in
		out_atm = 9.8692*val_in
		out_bar = 10.0*val_in
		out_msz = 101.972*val_in
	}
	else if(unit=='KPa'){
		out_MPa = 1e-3*val_in
		out_KPa = val_in
		out_Pa = 1e3*val_in
		out_mPa = 1e6*val_in
		out_psi = 0.145*val_in
		out_atm = 0.0098692*val_in
		out_bar = 0.01*val_in
		out_msz = 0.101972*val_in
	}
	else if(unit=='Pa'){
		out_MPa = 1e-6*val_in
		out_KPa = 1e-3*val_in
		out_Pa = val_in
		out_mPa = 1e3*val_in
		out_psi = 1.45e-4*val_in
		out_atm = 9.8692e-6*val_in
		out_bar = 1e-5*val_in
		out_msz = 1.01972e-4*val_in
	}
	else if(unit=='mPa'){
		out_MPa = 1e-9*val_in
		out_KPa = 1e-6*val_in
		out_Pa = 1e-3*val_in
		out_mPa = val_in
		out_psi = 1.45e-7*val_in
		out_atm = 9.8692e-9*val_in
		out_bar = 1e-8*val_in
		out_msz = 1.01972e-7*val_in
	}
	else if(unit=='psi'){
		out_MPa = 6.89655*1e-3*val_in
		out_KPa = 6.89655*val_in
		out_Pa = 6.89655*1e3*val_in
		out_mPa = 6.89655*1e6*val_in
		out_psi = val_in
		out_atm = 6.80634e-2*val_in
		out_bar = 6.89655e-2*val_in
		out_msz = 0.703255*val_in
	}
	else if(unit=='atm'){
		out_MPa = 1.01325*1e-1*val_in
		out_KPa = 1.01325*1e2*val_in
		out_Pa = 1.01325*1e5*val_in
		out_mPa = 1.01325*1e8*val_in
		out_psi = 1.469217*1e1*val_in
		out_atm = val_in
		out_bar = 1.01325*val_in
		out_msz = 1.03323*10*val_in
	}
	else if(unit=='bar'){
		out_MPa = 0.1*val_in
		out_KPa = 100*val_in
		out_Pa = 1e5*val_in
		out_mPa = 1e8*val_in
		out_psi = 14.5*val_in
		out_atm = 0.98692*val_in
		out_bar = val_in
		out_msz = 10.1972*val_in
	}
	else if(unit=='msz'){
		out_MPa = 0.0098066*val_in
		out_KPa = 9.8066135*val_in
		out_Pa = 9806.61358*val_in
		out_mPa = 9806613.580198*val_in
		out_psi = 1.4295897*val_in
		out_atm = 0.09678343*val_in
		out_bar = 0.980661358*val_in
		out_msz = val_in
	}

	
	out_MPa = num2e(out_MPa)
	out_KPa = num2e(out_KPa)
	out_Pa = num2e(out_Pa)
	out_mPa = num2e(out_mPa)
	out_psi = num2e(out_psi)
	out_atm = num2e(out_atm)
	out_bar = num2e(out_bar)
	out_msz = num2e(out_msz)

	result_pre.innerText = out_MPa+"MPa"+"           "+out_KPa+"KPa"+"           "+out_Pa+"Pa"+"           "+out_mPa+"mPa"+
	"           "+out_psi+"psi"+"           "+out_atm+"atm"+"           "+out_bar+"bar"+"           "+out_msz+"米水柱"
}

<!--压缩系数换算函数-->
function compress(){
	let data = document.getElementById('in_com').value
	let val_in = parseFloat(data)
	var eSelect = document.getElementById('choose_com')
	var index=eSelect.selectedIndex
	let unit = eSelect.options[index].value
	console.log(unit)
	if(unit=='MPa-1'){
		out_MPa = val_in
		out_KPa = 1e-3*val_in
		out_Pa = 1e-6*val_in
		out_mPa = 1e-9*val_in
		out_psi = val_in/145
	}
	else if(unit=='KPa-1'){
		out_MPa = 1/1e-3*val_in
		out_KPa = val_in
		out_Pa = 1/1e3*val_in
		out_mPa = 1/1e6*val_in
		out_psi = 1/0.145*val_in
	}
	else if(unit=='Pa-1'){
		out_MPa = 1/1e-6*val_in
		out_KPa = 1/1e-3*val_in
		out_Pa = val_in
		out_mPa = 1/1e3*val_in
		out_psi = 1/1.45e-4*val_in
	}
	else if(unit=='mPa-1'){
		out_MPa = 1/1e-9*val_in
		out_KPa = 1/1e-6*val_in
		out_Pa = 1/1e-3*val_in
		out_mPa = val_in
		out_psi = 1/1.45e-7*val_in
	}
	else if(unit=='psi-1'){
		out_MPa = 1/6.89655e-3*val_in
		out_KPa = 1/6.89655*val_in
		out_Pa = 1/6.89655e3*val_in
		out_mPa = 1/6.89655e6*val_in
		out_psi = val_in
	}


	
	out_MPa = num2e(out_MPa)
	out_KPa = num2e(out_KPa)
	out_Pa = num2e(out_Pa)
	out_mPa = num2e(out_mPa)
	out_psi = num2e(out_psi)


	result_com.innerText = out_MPa+"MPa-1"+"           "+out_KPa+"KPa-1"+"           "+out_Pa+"Pa-1"+"           "+out_mPa+"mPa-1"+
	"           "+out_psi+"psi-1"
}

<!--产量换算函数-->
function yied(){
	let data = document.getElementById('in_yied').value
	let val_in = parseFloat(data)
	var eSelect = document.getElementById('choose_yied')
	var index=eSelect.selectedIndex
	let unit = eSelect.options[index].value
	console.log(unit)
	if(unit=='stb/d'){
		out_1 = val_in
		out_2 = 0.159*val_in
		out_3 = 0.14*val_in
	}
	else if(unit=='m3/d'){
		out_1 = val_in*6.2893
		out_2 = val_in
		out_3 = val_in*0.8805
	}
	else if(unit=='t/d'){
		out_1 = val_in*7.1428
		out_2 = val_in*1.1357
		out_3 = val_in
	}
	
	out_1 = num2e(out_1)
	out_2 = num2e(out_2)
	out_3 = num2e(out_3)
	result_yied.innerHTML = out_1+"stb/d"+"           "+out_2+"m3/d"+"           "+out_3+"t/d"
}

<!--密度换算函数-->
function density(){
	let data = document.getElementById('in_den').value
	let val_in = parseFloat(data)
	var eSelect = document.getElementById('choose_den')
	var index=eSelect.selectedIndex
	let unit = eSelect.options[index].value
	console.log(unit)
	if(unit=='gcm'){
		out_1 = val_in
		out_2 = val_in*1000
		out_3 = val_in*62.42197
	}
	else if(unit=='kgm'){
		out_1 = val_in*0.001
		out_2 = val_in
		out_3 = val_in*0.06242197
	}
	else if(unit=='lamft'){
		out_1 = val_in*0.01602
		out_2 = val_in*16.02
		out_3 = val_in
	}
	
	out_1 = num2e(out_1)
	out_2 = num2e(out_2)
	out_3 = num2e(out_3)
	result_den.innerHTML = out_1+"g/cm^3"+"           "+out_2+"kg/m^3"+"           "+out_3+"lam(lb)/ft^3"
}

<!--温度换算函数-->
function temperature(){
	let data = document.getElementById('in_tem').value
	let val_in = parseFloat(data)
	var eSelect = document.getElementById('choose_tem')
	var index=eSelect.selectedIndex
	let unit = eSelect.options[index].value
	console.log(unit)
	if(unit=='ssd'){
		out_1 = val_in
		out_2 = val_in*1.8+32
		out_3 = val_in+273.15
	}
	else if(unit=='F'){
		out_1 = (val_in-32)/1.8
		out_2 = val_in
		out_3 = (val_in-32)/1.8+273.15
	}
	else if(unit=='K'){
		out_1 = val_in-273.15
		out_2 = (val_in-273.15)*1.8+32
		out_3 = val_in
	}
	
	out_1 = num3e(out_1)
	out_2 = num3e(out_2)
	out_3 = num3e(out_3)
	result_tem.innerHTML = out_1+"℃"+"           "+out_2+"F"+"           "+out_3+"K"
}

